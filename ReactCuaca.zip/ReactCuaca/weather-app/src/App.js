import React, { useState } from 'react';
import './App.css';

function App() {
  const [city, setCity] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const API_KEY = '44d386b4e07a49dc9226f6b5e3611163';

  const getWeather = async () => {
    if (!city) return;
    setLoading(true);
    setError(null);
    setWeatherData(null);
    try {
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
      );
      if (!response.ok) throw new Error('Kota tidak ditemukan');
      const data = await response.json();
      setWeatherData(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <h1>Weather App</h1>
      <div>
        <input
          type="text"
          placeholder="Masukkan nama kota"
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <button onClick={getWeather}>Cari Cuaca</button>
      </div>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {weatherData && (
        <div className="weather-result">
          <h2>{weatherData.name}</h2>
          <p>Suhu: {weatherData.main.temp}°C</p>
          <p>Cuaca: {weatherData.weather[0].description}</p>
          <p>Kecepatan Angin: {weatherData.wind.speed} m/s</p>
        </div>
      )}

      {/* Tambahan Identitas */}
      <div className="footer">
        <p>Nama: Fachri Akbar</p>
        <p>Front-End Mentee Metro Institute</p>
      </div>
    </div>
  );
}

export default App;
